const mongoose = require("mongoose")

const Vendor = require("../models/vendor.model.js")

const Shop = require("../models/shop.model.js")

// get the file uploading settings from the middlewares
const upload = require("../middlewares/multer.middleware.js")
const uploadOnCloudinary = require("../utils/cloudinary.js")

const createVendor = async (req, res) => {
    try {
        
        const {name, email, password, phone} = req.body

        if(!name || !email || !password)
        {
            return res.status(400).json({
                success : false,
                message : "Kindly Fill all the details to create account",
                error : error
            })
        }

        if(!phone)
        {
            const newVendor = await Vendor.create({name, email, password})

            if(newVendor)
            {
                return res.status(201).json({
                    success : false,
                    message : "Vendor Account Created SuccessFully"
                })
            }
            else
            {
                return res.status(400).json({
                    success : false,
                    message : "Failed To Create Account Kindly Try again",
                    error : error
                })
            }
        }

        else
        {
            const newVendor = await Vendor.create({name, email, password, phone})

            if(newVendor)
            {
                return res.status(201).json({
                    success : false,
                    message : "Vendor Account Created SuccessFully"
                })
            }
            else
            {
                return res.status(400).json({
                    success : false,
                    message : "Failed To Create Account Kindly Try again",
                    error : error
                })
            }
        }

    } catch (error) {
        return res.status(500).json({
            success : false,
            message : "Failed To create Account Due to server. Please try again",
            error : error.message
        })
    }
}

const createShop = async (req, res) => {
    try {
        const {shopName, description, location, image} = req.body

        if(!shopName || !description || !location)
        {
            return res.status(400).json({
                success : false,
                message : "Kindly enter all details to create shop"
            })
        }

        if(!image)
        {
            const newShop = await Shop.create({shopName, description, location})
            if(newShop)
            {
                return res.json({
                    success : true,
                    message : "New Shop Created Successfully"
                })
            }
        }
        const newShop = await Shop.create({shopName, description, location, image})
        if(newShop)
        {
            return res.json({
                success : true,
                message : "New Shop Created Successfully"
            })
        }

        return res.status(500).json({
            success : false,
            message : "Failed To Create Shop due to db error please try later",
            error : error
        })
    } catch (error) {
        return res.status(500).json({
            success : false,
            message : "",
            error : error
        })   
    }
}

// const photoUploadUsingMulterAndCloudinary = async (req, res, next) => {

//     if(!req.file)
//     {
//         return res.send("No file found")
//     }
    
//     // This will have the path of the image
//     console.log("the file is ", req.file)
//     let localFilePath = req.file.path;
//     // This will upload the local file to the cloudinary
//     const result = await uploadOnCloudinary(localFilePath)
 
//     // Return the required result to the server
//     return res.status(200).json({
//         success: true, 
//         data: result
//     })

// }

const photoUploadUsingMulterAndCloudinary = async (req, res, next) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "No file found" });
        }

        console.log("Uploading file:", req.file.originalname);

        const fileBuffer = req.file.buffer; // Get file buffer
        const fileFormat = req.file.mimetype.split("/")[1]; // Extract file format

        const result = await uploadOnCloudinary(fileBuffer, fileFormat);

        return res.status(200).json({
            success: true,
            data: result
        });

    } catch (error) {
        return res.status(500).json({ success: false, message: "Upload failed", error });
    }
};


// This syntax is also used to export multiple functions from files
exports.createVendor = createVendor
exports.createShop = createShop
exports.photoUploadUsingMulterAndCloudinary = photoUploadUsingMulterAndCloudinary